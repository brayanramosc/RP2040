#ifndef _TIMER_H
#define _TIMER_H    

extern repeating_timer_t timer;

bool timer_init(int32_t);

#endif
